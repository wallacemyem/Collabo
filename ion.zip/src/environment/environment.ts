//you should replace this values with yours

export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyCHjrxeH8VUADKLhR5Csa54cqPRMDr4Pw8",
    authDomain: "rosy-dynamics-171007.firebaseapp.com",
    databaseURL: "https://rosy-dynamics-171007.firebaseio.com",
    projectId: "rosy-dynamics-171007",
    storageBucket: "rosy-dynamics-171007.appspot.com",
    messagingSenderId: "303898922125"
  },
  google_web_client_id: "1092390853283-i98feg7fb1dlsm92kkcbim62855pepi8.apps.googleusercontent.com",
  facebook_app_id: 826720427470540,
  wordpress_url: 'https://wordpress.startapplabs.com/blog/',
  wordpress_rest_api_url: 'https://wordpress.startapplabs.com/blog/wp-json/wp/v2/'
};
